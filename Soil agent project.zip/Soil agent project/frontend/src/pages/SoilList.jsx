import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Accordion from 'react-bootstrap/Accordion';
import ListGroup from 'react-bootstrap/ListGroup';
import {URL} from '../url'

const SoilList = () => {
  const [soils, setSoils] = useState([]); // State to hold soil data
  const [error, setError] = useState(null); // State to handle errors
  const [loading, setLoading] = useState(true); // State to handle loading status

  useEffect(() => {
    const fetchSoils = async () => {
      const token = localStorage.getItem('token'); // Retrieve the token from local storage

      try {
        setLoading(true); // Start loading
        const response = await axios.get(URL+'/api/user/soil', {
          headers: {
            'Authorization': `Bearer ${token}`, // Include the token in the Authorization header
          },
        });
        setSoils(response.data); // Set soil data
        console.log(response.data);
        console.log(token);
      } catch (err) {
        setError(err.message); // Set error message if request fails
      } finally {
        setLoading(false); // Stop loading
      }
    };

    fetchSoils();
  }, []);

  if (loading) return <p>Loading...</p>; // Show loading indicator
  if (error) return <p>Error: {error}</p>; // Show error message

  return (
    <div>
      <h2 id='title'>Soil Details</h2>
      <div className="container">
        <Accordion defaultActiveKey="0">
          {soils.map((soil) => (
            <Accordion.Item key={soil._id} eventKey={soil._id}>
              <Accordion.Header>{soil.type}</Accordion.Header>
              <Accordion.Body>
                <ListGroup variant="flush">
                  <ListGroup.Item variant="success">
                    <strong>pH level</strong>: "{soil.pH}"
                  </ListGroup.Item>
                  <ListGroup.Item variant="success">
                    <strong>Moisture Retentions</strong>: "{soil.moistureRetention}"
                  </ListGroup.Item>
                  <ListGroup.Item variant="success">
                    <strong>Nutrient Content</strong>: "{soil.nutrientContent}"
                  </ListGroup.Item>
                  <ListGroup.Item variant="success">
                    <strong>Recommended Crops</strong>: "{soil.recommendedCrops.join(', ')}"
                  </ListGroup.Item>
                </ListGroup>
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>
      </div>
    </div>
  );
};

export default SoilList;