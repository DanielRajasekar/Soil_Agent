

import React from 'react'
import SoilList from './SoilList'

const User = () => {
  return (
    <div><SoilList/></div>
  )
}

export default User