import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { URL } from '../url';

const Register = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('');
    const navigate = useNavigate(); // Use useNavigate for navigation

    const handleRegister = async (e) => {
        e.preventDefault(); // Prevent the default form submission behavior
        try {
            await axios.post(`${URL}/api/auth/register`, { username, email, password, role });
            // Reset the input fields after successful registration
            setUsername('');
            setEmail('');
            setPassword('');
            setRole('');
            navigate("/login"); // Navigate to the login page
        } catch (err) {
            console.log(err); // Handle error (you can also set an error state here)
        }
    };

    return (
        <div className="container mt-5">
            <h1>Register</h1>
            <form onSubmit={handleRegister}>
                <div className="form-group">
                    <label htmlFor="username">Username:</label>
                    <input
                        id="username"
                        value={username} // Set the value to the state variable
                        onChange={(e) => setUsername(e.target.value)}
                        type="text"
                        className="form-control"
                        placeholder='Enter your Username'
                        required
                    />
                </div>

                <div className="form-group mt-3">
                    <label htmlFor="email">Email:</label>
                    <input
                        id="email"
                        value={email} // Set the value to the state variable
                        onChange={(e) => setEmail(e.target.value)}
                        type="email" // Use type="email" for email validation
                        className="form-control"
                        placeholder='Enter Your Email id'
                        required
                    />
                </div>

                <div className="form-group mt-3">
                    <label htmlFor="password">Password:</label>
                    <input
                        id="password"
                        value={password} // Set the value to the state variable
                        onChange={(e) => setPassword(e.target.value)}
                        type="password"
                        className="form-control"
                        placeholder='Enter your Password'
                        required
                    />
                </div>

                <div className="form-group mt-3">
          <label htmlFor="role">Role:</label>
          <select
            id="role"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="form-control"
            required
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
        </div>

                <button type="submit" className="btn btn-primary mt-3">Register</button>
            </form>

            <h3 className="mt-3">
                <Link to="/login">Already have an account? Login</Link>
            </h3>
        </div>
    );
};

export default Register;