import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Accordion from 'react-bootstrap/Accordion';
import ListGroup from 'react-bootstrap/ListGroup';
import { URL } from '../url';

const DistributorsList = () => {
  const [distributors, setDistributors] = useState([]); // State to hold distributor data
  const [error, setError] = useState(null); // State to handle errors
  const [loading, setLoading] = useState(true); // State to handle loading status

  useEffect(() => {
    const fetchDistributors = async () => {
      try {
        setLoading(true); // Start loading
        const response = await axios.get(URL+'/api/user/distributors'); // API call
        setDistributors(response.data); // Set distributor data
        console.log(response.data);
      } catch (err) {
        setError(err.response ? err.response.data.message : err.message); // Set error message if request fails
      } finally {
        setLoading(false); // Stop loading
      }
    };

    fetchDistributors();
  }, []);

  if (loading) return <p>Loading...</p>; // Show loading indicator
  if (error) return <p>Error: {error}</p>; // Show error message

  return (
    <div>
      <h2 id='title'>Distributor Details</h2>
      <div className="container">
        <Accordion defaultActiveKey="0">
          {distributors.map((distributor) => (
            <Accordion.Item key={distributor._id} eventKey={distributor._id}>
              <Accordion.Header>{distributor.name}</Accordion.Header>
              <Accordion.Body>
                <ListGroup variant="flush">
                  <ListGroup.Item variant="success">
                    <strong>Contact Info:</strong> "{distributor.contactInfo}"
                  </ListGroup.Item>
                  <ListGroup.Item variant="success">
                    <strong>Location:</strong> "{distributor.location}"
                  </ListGroup.Item>
                  <ListGroup.Item variant="success">
                    <strong>Available Crops:</strong> "{distributor.availableCrops.join(", ")}"
                  </ListGroup.Item>
                </ListGroup>
              </Accordion.Body>
            </Accordion.Item>
          ))}
        </Accordion>
      </div>
    </div>
  );
};

export default DistributorsList;