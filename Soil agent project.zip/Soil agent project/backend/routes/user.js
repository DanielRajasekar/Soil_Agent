const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();
const User = require('../models/User');
const Soil = require('../models/Soil');
const Distributor = require('../models/Distributor');
const verifyToken = require('../verifyToken')


router.get('/users', async (req, res) => {
    try {
        const users = await User.find(); // Fetch user data from MongoDB
        res.json(users); // Send the user data as JSON
    } catch (error) {
        console.error('Error fetching users:', error); // Debug log
        res.status(500).json({ message: error.message }); // Send error response
    }
});

// View Soil Details
router.get('/soil',verifyToken, async (req, res) => {
    const soils = await Soil.find();
    res.json(soils);
});

// View Distributor Details
router.get('/distributors',verifyToken, async (req, res) => {
    const distributors = await Distributor.find();
    res.json(distributors);
});
module.exports = router;