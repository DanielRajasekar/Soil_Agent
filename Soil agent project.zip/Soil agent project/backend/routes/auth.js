const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();
const User = require('../models/User');

// User Registration
router.post('/register', async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const user = new User({ ...req.body, password: hashedPassword });
    await user.save();
    res.status(201).send(user);
});

// Login
router.post('/login', async(req,res)=>{
    try{
        const user= await User.findOne({email:req.body.email});
        if(!user) {
            return res.status(404).json('User not found')
        }

        const match = await bcrypt.compare(req.body.password,user.password);

        if(!match){
            return res.status(404).json('Wrong password')
        }
        const token = jwt.sign({_id:user._id,email:user.email},
            "Daniel",{expiresIn:"3d"})
            const {password, ...info}= user._doc

            res.cookie("token",token,{
                httpOnly:true,
                secure:true,
                sameSite:"none",
            }).status(200).json(info)

}
catch(err){
    res.status(500).json(err)
}

});

// Logout
router.get('/logout', async(req,res)=>{
    try{
        res.clearCookie("token",{sameSite:"none", secure:true})
        .status(200).send("logout success");
    }
    catch(err){
        res.status(500).json(err)
    }
});

// refetch
router.get("/refetch", (req,res) => {
    try{
        const token = req.cookies.token
        jwt.verify(token,"Daniel", {}, async(err,data) => {
            if(err) {
                return res.status(404).json(err)
            }
            res.status(200).json(data)
        })

    }
    catch (err){
        res.status(500).json(err)
    }
})

module.exports = router;