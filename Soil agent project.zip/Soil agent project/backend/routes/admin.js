const express = require('express');
// const bcrypt = require('bcryptjs');
// const jwt = require('jsonwebtoken');
const router = express.Router();
const Soil = require('../models/Soil');
const Distributor = require('../models/Distributor');

// Post Soil Details
router.post('/createSoil',async(req,res)=>{
    try {
    
        const newSoil = new Soil(req.body)

        const savedSoil = await newSoil.save()
        res.status(200).json(savedSoil)

    }
    catch (err) {
        res.status(500).json(err)
    }
});

// Post Distributors Details
router.post('/createDistributor',async(req,res)=>{
    try {
    
        const newDistributor = new Distributor(req.body)

        const savedDistributor = await newDistributor.save()
        res.status(200).json(savedDistributor)

    }
    catch (err) {
        res.status(500).json(err)
    }
});
module.exports = router;