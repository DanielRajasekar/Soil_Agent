const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const cookieParser = require('cookie-parser')
const adminRoute = require('./routes/admin');
const userRoute = require('./routes/user')
const authRoute = require('./routes/auth')
const app = express();
const PORT = process.env.PORT || 8000;




// app.use(cors())
// const corsOptions ={
//     origin:'*',
//     Credential:true
// };
const corsOptions = {
    origin: 'http://localhost:3000', 
    credentials: true,
  };
app.use(cors(corsOptions))

// middleware
// dotenv.config()
app.use(express.json())
app.use(cookieParser());
app.use('/api/auth',authRoute);
app.use('/api/admin',adminRoute);
app.use('/api/user',userRoute);


const connectDB = async()=>{
    try{
        await mongoose.connect('mongodb+srv://admin:admin@cluster0.r8psb.mongodb.net/')
        console.log('MongoDB connected')
    }
    catch(err){
        console.error("error in database "+err)
    }
}
app.listen(PORT,()=>{
    connectDB()
    console.log("server is running on port "+PORT)
})
