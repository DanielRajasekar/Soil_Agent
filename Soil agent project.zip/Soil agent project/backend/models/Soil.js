const mongoose = require('mongoose');

const soilSchema = new mongoose.Schema({
    type: String,
    pH: Number,
    moistureRetention: Number,
    nutrientContent: String,
    recommendedCrops: [String]
});

module.exports = mongoose.model('Soil', soilSchema);